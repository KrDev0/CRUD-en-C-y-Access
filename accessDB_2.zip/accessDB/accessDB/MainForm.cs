﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace accessDB
{
    public partial class MainForm : Form
    {

        // 'El proveedor 'Microsoft.ACE.OLEDB.12.0' no está registrado en el equipo local
        public MainForm()
        {
            InitializeComponent();
        }

        private void usuariosBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {

        }

        private void usuariosBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.usuariosBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.maindbDataSet);

        }

        private void usuariosBindingNavigatorSaveItem_Click_2(object sender, EventArgs e)
        {
            this.Validate();
            this.usuariosBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.maindbDataSet);

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            actualizar();
        }

        public void actualizar()
        {
            // TODO: esta línea de código carga datos en la tabla 'maindbDataSet.Usuarios' Puede moverla o quitarla según sea necesario.
            this.usuariosTableAdapter.Fill(this.maindbDataSet.Usuarios);
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.usuariosTableAdapter.InsertQuery(txtNOMBRE.Text,txtAPELLIDO.Text,txtDIR.Text);
            actualizar();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtID.Text);

            this.usuariosTableAdapter.UpdateQuery(txtNOMBRE.Text, txtAPELLIDO.Text, txtDIR.Text, id);
            actualizar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtID.Text);

            this.usuariosTableAdapter.DeleteQuery(id);
            actualizar();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtID.Text);

            this.usuariosTableAdapter.BuscarBy(maindbDataSet.Usuarios, id);
            //actualizar();
        }
    }
}
